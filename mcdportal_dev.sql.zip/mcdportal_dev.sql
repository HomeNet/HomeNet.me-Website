-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 22, 2011 at 10:45 PM
-- Server version: 5.5.11
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mcdportal_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_facebook`
--

CREATE TABLE IF NOT EXISTS `auth_facebook` (
  `id` int(10) unsigned NOT NULL,
  `hash` char(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_facebook`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_internal`
--

CREATE TABLE IF NOT EXISTS `auth_internal` (
  `id` int(11) unsigned NOT NULL,
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password` char(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_internal`
--

INSERT INTO `auth_internal` (`id`, `username`, `password`) VALUES
(2, 'testuser1', '0f8ebe3ad831094950a0984da34c6b3de6c22916'),
(3, 'testuser2', '1915c0372c0b3a1c9800658ac6475cd3af65281a'),
(4, 'testadmin', 'da1d7fad975c76b9f1739e98f88debd3840cbfe4'),
(5, 'testsuperadmin', 'd6c674a28ff0da09d6d7cbf85e7096282046eeb9');

-- --------------------------------------------------------

--
-- Table structure for table `background_images`
--

CREATE TABLE IF NOT EXISTS `background_images` (
  `id` int(11) NOT NULL,
  `src` varchar(29) NOT NULL,
  `name` varchar(128) NOT NULL,
  `credit` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `background_images`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_categories`
--

CREATE TABLE IF NOT EXISTS `content_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `set` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL,
  `title` varchar(128) CHARACTER SET utf8 NOT NULL,
  `description` varchar(512) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`),
  KEY `set` (`set`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `content_categories`
--

INSERT INTO `content_categories` (`id`, `set`, `parent`, `order`, `url`, `title`, `description`) VALUES
(1, 3, 0, 0, 'test3', 'test3', ''),
(2, 3, 0, 0, 'test2', 'Test2', ''),
(3, 1, 0, 0, 'photo', 'Photos', 'My Photos'),
(4, 1, 0, 0, 'web_design', 'Web Design', 'My Webdesign');

-- --------------------------------------------------------

--
-- Table structure for table `content_category_sets`
--

CREATE TABLE IF NOT EXISTS `content_category_sets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `package` varchar(32) CHARACTER SET latin1 DEFAULT NULL,
  `title` varchar(128) CHARACTER SET latin1 NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `content_category_sets`
--

INSERT INTO `content_category_sets` (`id`, `package`, `title`, `visible`) VALUES
(1, NULL, 'test', 1),
(2, NULL, 'test2', 1),
(3, NULL, 'test4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `content_content`
--

CREATE TABLE IF NOT EXISTS `content_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active_revision` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `section` int(10) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`),
  KEY `section` (`section`),
  KEY `active_revision` (`active_revision`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `content_content`
--

INSERT INTO `content_content` (`id`, `active_revision`, `section`, `url`, `visible`) VALUES
(1, '2011-09-16 09:14:10', 1, 'test_page', 0),
(2, '2011-09-16 08:55:51', 1, 'hello_world', 0),
(4, '2011-09-21 14:45:40', 1, 'test_project', 0),
(5, '2011-09-21 15:58:13', 1, 'yryryertyeryte', 0);

-- --------------------------------------------------------

--
-- Table structure for table `content_content_categories`
--

CREATE TABLE IF NOT EXISTS `content_content_categories` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `section` int(11) unsigned NOT NULL,
  `content` int(11) unsigned NOT NULL,
  `category` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `content` (`content`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `content_content_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_custom_1`
--

CREATE TABLE IF NOT EXISTS `content_custom_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `revision` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `owner` int(11) unsigned NOT NULL,
  `autosave` int(1) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` text,
  `content` longtext,
  `author` varchar(255) DEFAULT NULL COMMENT '@array',
  `categories` text,
  PRIMARY KEY (`id`,`revision`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `content_custom_1`
--

INSERT INTO `content_custom_1` (`id`, `revision`, `owner`, `autosave`, `title`, `url`, `content`, `author`, `categories`) VALUES
(1, '2011-09-16 08:51:36', 0, 0, 'Test Page', 'test_page', 'this is where the page content goes', 'Matthew', NULL),
(2, '2011-09-16 08:55:51', 0, 0, 'Hello World', 'hello_world', 'test', 'Name', NULL),
(1, '2011-09-16 09:11:18', 0, 0, 'Test Page', 'test_page', 'this is where the page content goes o yes', 'Matthew', NULL),
(1, '2011-09-16 09:11:42', 0, 0, 'Test Page', 'test_page', 'this is where the page content goes o yes', 'Matthew', NULL),
(1, '2011-09-16 09:11:49', 0, 0, 'Test Page', 'test_page', 'this is where the page content goes o yes 2', 'Matthew', NULL),
(1, '2011-09-16 09:11:59', 0, 0, 'Test Page', 'test_page', 'this is where the page content goes o yes 2', 'Matthew', NULL),
(1, '2011-09-16 09:14:10', 0, 0, 'Test Page', 'test_page', 'this is where the page content goes o yes 3', 'Matthew', NULL),
(4, '2011-09-21 14:42:45', 0, 0, 'Test project', 'test_project', 'Test My Platofm', 'Matthew D', '4'),
(4, '2011-09-21 14:45:40', 0, 0, 'Test project', 'test_project', 'Test My Platofm', 'Matthew D', '3'),
(5, '2011-09-21 15:41:52', 0, 0, 'test3', 'myTest', 'eryrtyeryey this was updated', 'Name', 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}'),
(5, '2011-09-21 14:55:00', 0, 0, 'test3', 'myTest', 'eryrtyeryey', 'Name', 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}'),
(5, '2011-09-21 14:55:23', 0, 0, 'test3', 'myTest', 'eryrtyeryey this was updated', 'Name', 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}'),
(5, '2011-09-21 15:29:15', 0, 0, 'test3', 'myTest', 'eryrtyeryey this was updated', 'Name', 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}'),
(5, '2011-09-21 15:41:21', 0, 0, 'test3', 'myTest', 'eryrtyeryey this was updated', 'Name', 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}'),
(5, '2011-09-21 15:54:17', 0, 0, 'test3', 'testsdfdsfs', 'eryrtyeryey this was updated yryryryryr', 'Name', 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}'),
(5, '2011-09-21 15:58:13', 0, 0, 'test3', 'yryryertyeryte', 'eryrtyeryey this was updated yryryryryr gdsdfsgfsdfggsdfg', 'Name2', 'a:1:{i:0;s:1:"3";}');

-- --------------------------------------------------------

--
-- Table structure for table `content_custom_2`
--

CREATE TABLE IF NOT EXISTS `content_custom_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `revision` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `owner` int(11) unsigned NOT NULL,
  `autosave` int(1) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` text,
  PRIMARY KEY (`id`,`revision`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `content_custom_2`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_fields`
--

CREATE TABLE IF NOT EXISTS `content_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `section` int(10) unsigned NOT NULL,
  `set` int(11) NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL,
  `element` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `label` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `description` tinytext NOT NULL,
  `attributes` mediumtext,
  `validators` mediumtext,
  `options` mediumtext,
  `filters` mediumtext,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `content_fields`
--

INSERT INTO `content_fields` (`id`, `section`, `set`, `order`, `type`, `element`, `name`, `label`, `value`, `description`, `attributes`, `validators`, `options`, `filters`, `required`, `visible`, `locked`) VALUES
(1, 1, 0, 0, 0, 'text', 'title', 'Title', '', '', 'a:0:{}', 'a:0:{}', NULL, 'a:0:{}', 1, 1, 0),
(2, 1, 0, 1, 0, 'url', 'url', 'Url', '', '', 'a:0:{}', 'a:0:{}', NULL, 'a:0:{}', 1, 1, 0),
(3, 1, 0, 2, 1, 'textarea', 'content', 'Content', '', '', 'a:0:{}', 'a:0:{}', NULL, 'a:0:{}', 1, 1, 0),
(4, 1, 0, 6, 2, 'Text', 'author', 'Author', 'Name', 'test', 'a:0:{}', 'a:0:{}', NULL, 'a:0:{}', 0, 1, 0),
(7, 1, 4, 1, 2, 'Categories', 'categories', 'Categories', '', 'Select Categories this Content Belongs too', 'a:0:{}', 'a:0:{}', 'a:1:{s:3:"set";s:1:"1";}', 'a:0:{}', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `content_field_sets`
--

CREATE TABLE IF NOT EXISTS `content_field_sets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `section` int(11) unsigned NOT NULL,
  `order` int(11) NOT NULL,
  `title` varchar(128) CHARACTER SET latin1 NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `content_field_sets`
--

INSERT INTO `content_field_sets` (`id`, `section`, `order`, `title`, `visible`) VALUES
(1, 4, 0, 'Publish', 1),
(2, 5, 0, 'Publish', 1),
(3, 6, 0, 'Publish', 1),
(4, 1, 0, 'Publish', 1),
(6, 1, 0, 'tesdfgdg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `content_sections`
--

CREATE TABLE IF NOT EXISTS `content_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `package` varchar(32) DEFAULT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `content_sections`
--

INSERT INTO `content_sections` (`id`, `package`, `visible`, `title`, `url`, `description`) VALUES
(1, 'Pages', 0, 'Pages', 'pages', '');

-- --------------------------------------------------------

--
-- Table structure for table `content_templates`
--

CREATE TABLE IF NOT EXISTS `content_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `revision` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `owner` int(10) unsigned NOT NULL,
  `section` int(10) unsigned NOT NULL,
  `autosave` tinyint(4) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`,`revision`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `content_templates`
--

INSERT INTO `content_templates` (`id`, `revision`, `owner`, `section`, `autosave`, `url`, `active`, `visible`, `content`) VALUES
(1, '2011-09-13 04:23:35', 5, 4, 0, 'test', 0, 0, 'erwrwrwrwerwrwr'),
(2, '2011-09-13 04:29:47', 5, 4, 0, 'index', 0, 0, 'this is the index page'),
(1, '2011-09-13 04:46:03', 5, 4, 0, 'test', 0, 0, 'erwrwrwrwerwrwr test'),
(1, '2011-09-13 04:46:12', 5, 4, 0, 'test', 0, 0, 'erwrwrwrwerwrwr test test'),
(1, '2011-09-13 04:53:31', 5, 4, 0, 'test', 0, 0, 'erwrwrwrwerwrwr test test test'),
(2, '2011-09-13 04:53:43', 5, 4, 0, 'index', 0, 0, 'this is the index page and edited'),
(4, '2011-09-16 09:27:34', 5, 1, 0, 'index', 0, 0, 'index page'),
(4, '2011-09-16 09:27:51', 5, 1, 0, 'index2', 0, 0, 'index page2'),
(4, '2011-09-16 09:27:57', 5, 1, 0, 'index2', 0, 0, 'index page2'),
(5, '2011-09-16 10:11:56', 5, 1, 0, 'index', 0, 0, 'test'),
(6, '2011-09-16 10:15:03', 5, 1, 0, 'tedfgdfg', 0, 0, 'dfsgfgfg'),
(7, '2011-09-16 10:16:49', 5, 1, 0, '  vbncgn', 0, 0, 'cjfgjhdfh'),
(7, '2011-09-22 15:22:23', 5, 1, 0, 'index', 1, 0, 'test page');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(10) unsigned DEFAULT NULL,
  `type` tinyint(4) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` tinytext NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `user_count` int(11) unsigned NOT NULL DEFAULT '0',
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `parent`, `type`, `title`, `description`, `visible`, `user_count`, `settings`) VALUES
(1, NULL, 0, 'Everyone', 'Privileges granted to every user', 0, 0, 'a:0:{}'),
(2, NULL, 0, 'Owner', 'Privileges granted to the creator of a content item', 0, 0, 'a:0:{}'),
(3, NULL, 1, 'Guests', 'Users that have not been Authenticated', 0, 1, 'a:0:{}'),
(4, NULL, 1, 'Members', 'Authenticated Users', 1, 2, 'a:0:{}'),
(5, NULL, 1, 'Admins', 'Admin Site Content', 1, 1, 'a:0:{}'),
(6, NULL, 1, 'Site Admins', 'Full access to Site', 0, 1, 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `group_acls`
--

CREATE TABLE IF NOT EXISTS `group_acls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` int(10) unsigned NOT NULL,
  `module` varchar(16) DEFAULT NULL,
  `controller` varchar(16) DEFAULT NULL,
  `action` varchar(16) DEFAULT NULL,
  `object` int(11) DEFAULT NULL,
  `permission` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group` (`group`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `group_acls`
--

INSERT INTO `group_acls` (`id`, `group`, `module`, `controller`, `action`, `object`, `permission`) VALUES
(1, 1, 'core', 'error', NULL, NULL, 1),
(2, 1, 'core', 'login', 'logout', NULL, 1),
(3, 2, NULL, NULL, 'edit', NULL, 1),
(4, 2, NULL, NULL, 'delete', NULL, 1),
(5, 3, 'core', 'index', NULL, NULL, 1),
(6, 3, 'core', 'login', NULL, NULL, 1),
(7, 3, 'core', 'index', NULL, NULL, 1),
(8, 3, 'core', 'user', 'new', NULL, 1),
(9, 3, 'core', 'user', 'next-steps', NULL, 1),
(10, 3, 'core', 'user', 'send-activation', NULL, 1),
(11, 3, 'core', 'user', 'activate', NULL, 1),
(12, 4, 'core', 'index', NULL, NULL, 1),
(13, 4, 'core', 'user', NULL, NULL, 1),
(14, 4, 'core', 'gTest', 'index', NULL, 1),
(15, 4, 'core', 'gTest', 'add', NULL, 1),
(16, 4, 'core', 'gTest', 'edit', NULL, 0),
(17, 4, 'core', 'gTest', 'edit', 1, 1),
(18, 4, 'core', 'gTest', 'edit', 2, 0),
(19, 6, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `homenet_alerts`
--

CREATE TABLE IF NOT EXISTS `homenet_alerts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` int(11) DEFAULT NULL,
  `house` int(11) DEFAULT NULL,
  `room` int(11) DEFAULT NULL,
  `subdevice` int(11) DEFAULT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `message` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=107 ;

--
-- Dumping data for table `homenet_alerts`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_apikeys`
--

CREATE TABLE IF NOT EXISTS `homenet_apikeys` (
  `id` char(40) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `house` int(10) unsigned NOT NULL,
  `user` int(10) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permissions` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homenet_apikeys`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_boolean`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_boolean` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subdevice` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `value` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subdevice` (`subdevice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `homenet_datapoints_boolean`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_byte`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_byte` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subdevice` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `value` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=84236 ;

--
-- Dumping data for table `homenet_datapoints_byte`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_float`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_float` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subdevice` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subdevice` (`subdevice`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97970 ;

--
-- Dumping data for table `homenet_datapoints_float`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_int`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_int` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subdevice` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subdevice` (`subdevice`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `homenet_datapoints_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_long`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_long` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subdevice` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `value` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20941 ;

--
-- Dumping data for table `homenet_datapoints_long`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_devices`
--

CREATE TABLE IF NOT EXISTS `homenet_devices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `node` int(10) unsigned NOT NULL,
  `model` int(10) unsigned NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `subdevices` tinyint(3) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `settings` text CHARACTER SET utf8 COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `model` (`model`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=147 ;

--
-- Dumping data for table `homenet_devices`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_device_models`
--

CREATE TABLE IF NOT EXISTS `homenet_device_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '-1',
  `category` int(10) unsigned NOT NULL,
  `driver` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `image` tinytext,
  `settings` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `homenet_device_models`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_houses`
--

CREATE TABLE IF NOT EXISTS `homenet_houses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL,
  `url` varchar(16) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(128) CHARACTER SET utf8 NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 NOT NULL,
  `location` varchar(128) CHARACTER SET utf8 NOT NULL,
  `gps` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(16) CHARACTER SET utf8 NOT NULL,
  `regions` varchar(255) CHARACTER SET utf8 NOT NULL,
  `settings` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `permissions` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `homenet_houses`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_house_users`
--

CREATE TABLE IF NOT EXISTS `homenet_house_users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `house` int(10) unsigned NOT NULL,
  `user` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `house` (`house`,`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `homenet_house_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_nodes`
--

CREATE TABLE IF NOT EXISTS `homenet_nodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `node` int(10) unsigned NOT NULL,
  `model` smallint(10) unsigned NOT NULL,
  `uplink` int(11) unsigned DEFAULT NULL,
  `house` int(10) unsigned NOT NULL,
  `room` int(10) unsigned NOT NULL,
  `description` tinytext CHARACTER SET utf8 NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `node_id` (`model`,`house`,`room`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=108 ;

--
-- Dumping data for table `homenet_nodes`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_nodes_internet`
--

CREATE TABLE IF NOT EXISTS `homenet_nodes_internet` (
  `id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `ipaddress` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `direction` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_nodes_internet`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_node_models`
--

CREATE TABLE IF NOT EXISTS `homenet_node_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '-1',
  `type` tinyint(4) NOT NULL,
  `driver` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 NOT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `max_devices` smallint(5) unsigned NOT NULL DEFAULT '4',
  `settings` longtext CHARACTER SET utf8 COLLATE utf8_bin,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `homenet_node_models`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_packets`
--

CREATE TABLE IF NOT EXISTS `homenet_packets` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `received` datetime NOT NULL,
  `apikey` char(40) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `settings` tinyint(3) unsigned NOT NULL,
  `from_node` smallint(5) unsigned NOT NULL,
  `from_device` tinyint(3) unsigned NOT NULL,
  `to_node` smallint(5) unsigned NOT NULL,
  `to_device` tinyint(3) unsigned NOT NULL,
  `ttl` tinyint(3) unsigned DEFAULT NULL,
  `id` tinyint(3) unsigned NOT NULL,
  `command` tinyint(3) unsigned NOT NULL,
  `reply` tinyint(3) unsigned DEFAULT NULL,
  `payload` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `checksum` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=187773 ;

--
-- Dumping data for table `homenet_packets`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_rooms`
--

CREATE TABLE IF NOT EXISTS `homenet_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `house` int(10) unsigned NOT NULL,
  `region` char(1) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `name` varchar(128) CHARACTER SET utf8 NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `permissions` text CHARACTER SET utf8 COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `house` (`house`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `homenet_rooms`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_subdevices`
--

CREATE TABLE IF NOT EXISTS `homenet_subdevices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device` int(10) unsigned NOT NULL,
  `model` int(10) unsigned NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `room` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET utf8 NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `settings` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `permissions` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device` (`device`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=182 ;

--
-- Dumping data for table `homenet_subdevices`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_subdevice_models`
--

CREATE TABLE IF NOT EXISTS `homenet_subdevice_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '-1',
  `driver` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `description` tinytext COLLATE utf8_bin NOT NULL,
  `units` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `settings` text COLLATE utf8_bin NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=24 ;

--
-- Dumping data for table `homenet_subdevice_models`
--


-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '1',
  `package` varchar(64) DEFAULT NULL,
  `title` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `type`, `package`, `title`, `visible`) VALUES
(1, NULL, NULL, 'test', 1),
(2, NULL, NULL, 'test2', 1),
(3, NULL, NULL, 'test4', 1),
(4, NULL, NULL, 'uioouiuouiouoiui', 1),
(6, NULL, NULL, 'jljljljljlj', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE IF NOT EXISTS `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL,
  `route` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `options` text,
  `title` varchar(128) CHARACTER SET utf8 NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `set` (`menu`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu`, `parent`, `order`, `type`, `route`, `options`, `title`, `visible`) VALUES
(1, 3, 0, 0, 0, 'test3', NULL, 'test3', 0),
(2, 3, 0, 0, 0, 'test2', NULL, 'Test2', 0),
(5, 6, 0, 45, 1, 'sdfas', 'a:1:{s:6:"action";s:4:"test";}', 'test', 0),
(6, 6, 0, 5, 3, 'test', 'a:1:{s:7:"dfgdfgd";s:5:"dsfsd";}', 'lughfghfgh', 0),
(7, 6, 0, 4, 2, NULL, NULL, '---Divider---', 0),
(8, 6, 0, 6, 2, NULL, NULL, '---Divider---', 0);

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE IF NOT EXISTS `routes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL,
  `package` varchar(64) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL,
  `path` varchar(255) NOT NULL,
  `module` varchar(64) DEFAULT NULL,
  `controller` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `options` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `type`, `package`, `order`, `active`, `name`, `path`, `module`, `controller`, `action`, `options`) VALUES
(3, 'Routes', NULL, 1, 1, 'sdfas', 'sdfsdfasdf', 'sdfafadf', 'asdfadf', 'asdfasdf', 'a:1:{i:0;s:4:"test";}'),
(4, 'Routes', NULL, 1, 0, 'test', 'test/:action', 'test', 'test', 'test', 'a:1:{s:15:"defaults.action";s:3:"new";}'),
(5, 'Routes', NULL, 1, 0, 'testsfds', 'sdfsfsfs', 'sdfsfsf', '', '', 'a:1:{s:8:"defaults";a:1:{s:6:"action";s:1:"1";}}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '-1',
  `primary_group` int(10) unsigned NOT NULL DEFAULT '10',
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `name` varchar(56) CHARACTER SET utf8 NOT NULL,
  `location` varchar(128) CHARACTER SET utf8 NOT NULL,
  `email` varchar(128) CHARACTER SET utf8 NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permissions` text CHARACTER SET utf8 COLLATE utf8_bin,
  `settings` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `status`, `primary_group`, `username`, `name`, `location`, `email`, `created`, `permissions`, `settings`) VALUES
(1, 1, 3, 'Guest', 'Guest', 'Guest Location', 'guest@mcdportal.com', '2011-09-14 22:38:22', NULL, 0x613a303a7b7d),
(2, 1, 4, 'TestUser1', 'Test User', 'Random', 'testuser1@mcdportal.com', '2011-09-14 22:38:22', NULL, 0x613a303a7b7d),
(3, 1, 4, 'TestUser2', 'Test Special User ', 'Random', 'testuser2@mcdportal.com', '2011-09-14 22:38:22', NULL, 0x613a303a7b7d),
(4, 1, 5, 'TestAdmin', 'Test User', 'Random', 'testadmin@mcdportal.com', '2011-09-14 22:38:22', NULL, 0x613a303a7b7d),
(5, 1, 6, 'TestSuperAdmin', 'Test Super User', 'Random', 'testsuperadmin@mcdportal.com', '2011-09-14 22:38:22', NULL, 0x613a303a7b7d);

-- --------------------------------------------------------

--
-- Table structure for table `user_acls`
--

CREATE TABLE IF NOT EXISTS `user_acls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(10) unsigned NOT NULL,
  `module` varchar(16) DEFAULT NULL,
  `controller` varchar(16) DEFAULT NULL,
  `action` varchar(16) DEFAULT NULL,
  `object` int(11) DEFAULT NULL,
  `permission` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user_acls`
--

INSERT INTO `user_acls` (`id`, `user`, `module`, `controller`, `action`, `object`, `permission`) VALUES
(1, 2, 'core', 'uTest', 'index', NULL, 1),
(2, 2, 'core', 'uTest', 'add', NULL, 1),
(3, 2, 'core', 'uTest', 'edit', NULL, 0),
(4, 2, 'core', 'uTest', 'edit', 1, 1),
(5, 2, 'core', 'uTest', 'edit', 2, 0),
(6, 3, 'core', 'test', 'special', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_memberships`
--

CREATE TABLE IF NOT EXISTS `user_memberships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(10) unsigned NOT NULL,
  `group` int(10) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `user_memberships`
--

INSERT INTO `user_memberships` (`id`, `user`, `group`, `created`) VALUES
(1, 1, 3, '2011-09-07 20:46:17'),
(2, 2, 4, '2011-09-07 20:46:17'),
(3, 3, 4, '2011-09-07 20:46:17'),
(4, 4, 5, '2011-09-07 20:46:17'),
(5, 5, 6, '2011-09-07 20:46:17'),
(6, 1, 3, '2011-09-14 22:35:49'),
(7, 2, 4, '2011-09-14 22:35:49'),
(8, 3, 4, '2011-09-14 22:35:49'),
(9, 4, 5, '2011-09-14 22:35:49'),
(10, 5, 6, '2011-09-14 22:35:49'),
(11, 1, 3, '2011-09-14 22:35:56'),
(12, 2, 4, '2011-09-14 22:35:56'),
(13, 3, 4, '2011-09-14 22:35:56'),
(14, 4, 5, '2011-09-14 22:35:56'),
(15, 5, 6, '2011-09-14 22:35:56'),
(16, 1, 3, '2011-09-14 22:36:40'),
(17, 2, 4, '2011-09-14 22:36:40'),
(18, 3, 4, '2011-09-14 22:36:40'),
(19, 4, 5, '2011-09-14 22:36:40'),
(20, 5, 6, '2011-09-14 22:36:40'),
(21, 1, 3, '2011-09-14 22:38:22'),
(22, 2, 4, '2011-09-14 22:38:22'),
(23, 3, 4, '2011-09-14 22:38:22'),
(24, 4, 5, '2011-09-14 22:38:22'),
(25, 5, 6, '2011-09-14 22:38:22');
