-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Host: 
-- Generation Time: Jan 27, 2011 at 11:09 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `homenetm_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_facebook`
--

CREATE TABLE IF NOT EXISTS `auth_facebook` (
  `id` int(10) unsigned NOT NULL,
  `hash` char(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_facebook`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_internal`
--

CREATE TABLE IF NOT EXISTS `auth_internal` (
  `id` int(11) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_internal`
--

INSERT INTO `auth_internal` VALUES(2, '0', '34fd70478f6e54b4e2625f5804a461ba');
INSERT INTO `auth_internal` VALUES(8, '0', '067882305fe14af93491d1e57a71b2cf');
INSERT INTO `auth_internal` VALUES(9, '0', '82358d20cc9fb252f7f972b0c9483dd7');
INSERT INTO `auth_internal` VALUES(10, 'qwertyu', '298473d81f1b3b0ad46252b763359c2a');

-- --------------------------------------------------------

--
-- Table structure for table `background_images`
--

CREATE TABLE IF NOT EXISTS `background_images` (
  `id` int(11) NOT NULL,
  `src` varchar(29) NOT NULL,
  `name` varchar(128) NOT NULL,
  `credit` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `background_images`
--


-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL,
  `set` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned default NULL,
  `order` int(10) unsigned NOT NULL default '0',
  `title` varchar(128) NOT NULL,
  `description` varchar(512) default NULL,
  PRIMARY KEY  (`id`),
  KEY `set` (`set`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `category_sets`
--

CREATE TABLE IF NOT EXISTS `category_sets` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_sets`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_apikeys`
--

CREATE TABLE IF NOT EXISTS `homenet_apikeys` (
  `id` char(25) NOT NULL,
  `home` int(10) unsigned NOT NULL,
  `user` int(10) unsigned NOT NULL,
  `permissions` varchar(256) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_apikeys`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_boolean`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_boolean` (
  `id` bigint(20) unsigned NOT NULL,
  `subdevice` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `value` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `subdevice` (`subdevice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_datapoints_boolean`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_float`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_float` (
  `id` bigint(20) unsigned NOT NULL,
  `subdevice` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `subdevice` (`subdevice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_datapoints_float`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_datapoints_int`
--

CREATE TABLE IF NOT EXISTS `homenet_datapoints_int` (
  `id` bigint(20) unsigned NOT NULL,
  `subdevice` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `subdevice` (`subdevice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_datapoints_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_devices`
--

CREATE TABLE IF NOT EXISTS `homenet_devices` (
  `id` int(10) unsigned NOT NULL,
  `model` int(10) unsigned NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `model` (`model`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_devices`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_device_models`
--

CREATE TABLE IF NOT EXISTS `homenet_device_models` (
  `id` int(10) unsigned NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_device_models`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_houses`
--

CREATE TABLE IF NOT EXISTS `homenet_houses` (
  `id` int(10) unsigned NOT NULL,
  `url` varchar(16) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(255) NOT NULL,
  `gps` varchar(128) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_houses`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_house_users`
--

CREATE TABLE IF NOT EXISTS `homenet_house_users` (
  `id` mediumint(8) unsigned NOT NULL,
  `house` int(10) unsigned NOT NULL,
  `user` int(10) unsigned NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `house` (`house`,`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_house_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_nodes`
--

CREATE TABLE IF NOT EXISTS `homenet_nodes` (
  `id` int(10) unsigned NOT NULL,
  `type` smallint(10) unsigned NOT NULL,
  `uplink_id` int(11) NOT NULL,
  `house` int(10) unsigned NOT NULL,
  `room` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `node_id` (`type`,`house`,`room`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_nodes`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_nodes_internet`
--

CREATE TABLE IF NOT EXISTS `homenet_nodes_internet` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_nodes_internet`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_packets`
--

CREATE TABLE IF NOT EXISTS `homenet_packets` (
  `pid` int(10) unsigned NOT NULL,
  `received` datetime NOT NULL,
  `apikey` char(25) NOT NULL,
  `settings` tinyint(3) unsigned NOT NULL,
  `from_node` smallint(5) unsigned NOT NULL,
  `from_device` tinyint(3) unsigned NOT NULL,
  `to_node` smallint(5) unsigned NOT NULL,
  `to_device` tinyint(3) unsigned NOT NULL,
  `ttl` tinyint(3) unsigned NOT NULL,
  `id` tinyint(3) unsigned NOT NULL,
  `command` tinyint(3) unsigned NOT NULL,
  `reply` tinyint(3) unsigned NOT NULL,
  `payload` varchar(128) NOT NULL,
  `checksum` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_packets`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_rooms`
--

CREATE TABLE IF NOT EXISTS `homenet_rooms` (
  `id` int(10) unsigned NOT NULL,
  `house` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `house` (`house`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_rooms`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_subdevices`
--

CREATE TABLE IF NOT EXISTS `homenet_subdevices` (
  `id` int(10) unsigned NOT NULL,
  `device` int(10) unsigned NOT NULL,
  `device_model` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `units` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `device` (`device`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_subdevices`
--


-- --------------------------------------------------------

--
-- Table structure for table `homenet_subdevice_types`
--

CREATE TABLE IF NOT EXISTS `homenet_subdevice_types` (
  `id` int(10) unsigned NOT NULL,
  `device` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(16) NOT NULL,
  `byteformat` varchar(5) NOT NULL,
  `units` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homenet_subdevice_types`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `status` tinyint(4) NOT NULL default '-1',
  `username` varchar(32) NOT NULL,
  `name` varchar(56) NOT NULL,
  `location` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(1, -1, 'qq', 'qqqqq', 'qqqqq', 'q@q.com', '');
INSERT INTO `users` VALUES(2, -1, 'qq', 'qqqqq', 'qqqqq', 'q@q.com', '');
INSERT INTO `users` VALUES(3, -1, 'qq', 'qqqqq', 'qqqqq', 'q@q.com', '');
INSERT INTO `users` VALUES(4, -1, 'test', 'test', 'test', 'test@test.com', '');
INSERT INTO `users` VALUES(5, -1, 'test', 'test', 'test', 'test@test.com', '');
INSERT INTO `users` VALUES(6, -1, 'test', 'test', 'test', 'test@test.com', '');
INSERT INTO `users` VALUES(7, -1, 'test', 'test', 'test', 'test@test.com', '');
INSERT INTO `users` VALUES(8, -1, 'test', 'test', 'test', 'test@test.com', '');
INSERT INTO `users` VALUES(9, -1, 'gdfgfdg', 'gdfgfdg', 'gdfgfdg', 'gdfgfdg@gdfgfdg.com', '');
INSERT INTO `users` VALUES(10, -1, 'qwertyu', 'qwertyu', 'qwertyu', 'qwertyu@qwertyu.com', '');
